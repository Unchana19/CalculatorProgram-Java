import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;


import static java.lang.StrictMath.pow;

public class MainFrame extends JFrame {
    private JTextField Input1;
    private JLabel Resulttext;
    private JPanel Main;
    private JLabel Head;
    private JButton plus;
    private JButton divide;
    private JButton minus;
    private JButton multiply;
    private JTextField Input2;
    private JButton Pow;
    private JButton Root;
    private JButton Clear;
    private JButton Clipboadbut;
    private JLabel Copytxt;


    public MainFrame() {
        plus.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double input1 = Double.parseDouble(Input1.getText());
                double input2 = Double.parseDouble(Input2.getText());
                double result = input1 + input2;
                Resulttext.setText(""+result);
            }
        });
        minus.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double input1 = Double.parseDouble(Input1.getText());
                double input2 = Double.parseDouble(Input2.getText());
                double result = input1 - input2;
                Resulttext.setText(""+result);
            }
        });
        multiply.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double input1 = Double.parseDouble(Input1.getText());
                double input2 = Double.parseDouble(Input2.getText());
                double result = input1 * input2;
                Resulttext.setText(""+result);
            }
        });
        divide.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double input1 = Double.parseDouble(Input1.getText());
                double input2 = Double.parseDouble(Input2.getText());
                double result = input1 / input2;
                Resulttext.setText(""+result);
            }
        });
        Pow.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double input1 = Double.parseDouble(Input1.getText());
                double input2 = Double.parseDouble(Input2.getText());
                double result = pow(input1,input2);
                Resulttext.setText(""+result);
            }
        });
        Root.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double input1 = Double.parseDouble(Input1.getText());
                double input2 = Double.parseDouble(Input2.getText());
                double result = pow(input1,1/input2);
                DecimalFormat decimalFormat = new DecimalFormat("#.####");
                float Resultroot = Float.valueOf(decimalFormat.format(result));
                Resulttext.setText(""+Resultroot);
            }
        });
        Clear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Input1.setText("");
                Input2.setText("");
                Resulttext.setText("Result");
            }
        });
        Clipboadbut.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String resulttxt = String.valueOf(Resulttext.getText());
                StringSelection selection = new StringSelection(resulttxt);
                Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
                clipboard.setContents(selection, selection);
            }
        });
    }


    public static void main(String args[]){
        MainFrame f = new MainFrame();
        ImageIcon imgicon = new ImageIcon("C:\\Users\\Super_Computer\\IdeaProjects\\project\\src\\images.png");
        f.setContentPane(new MainFrame().Main);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);
        f.pack();
        f.setTitle("Calculator");
        f.setIconImage(imgicon.getImage());
    }
}
